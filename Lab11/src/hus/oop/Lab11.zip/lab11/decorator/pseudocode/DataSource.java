package hus.oop.lab11.decorator.pseudocode;

public interface DataSource {
    void writeData(String data);

    String readData();
}
