package hus.oop.lab11.decorator.shape;

public interface Shape {
    void draw();
}
