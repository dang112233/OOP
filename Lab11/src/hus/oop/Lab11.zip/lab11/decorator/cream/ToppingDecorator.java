package hus.oop.lab11.decorator.cream;

public abstract class ToppingDecorator extends IceCream {
    abstract String addTopping();
}