package hus.oop.lab11.decorator.cream;

public class VanillaIceCream extends IceCream {
    public VanillaIceCream() {

    }

    @Override
    String getDescription() {
        return "Vanilla ice cream";
    }
}
