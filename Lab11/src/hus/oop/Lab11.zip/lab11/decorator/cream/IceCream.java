package hus.oop.lab11.decorator.cream;

public abstract class IceCream {
    abstract String getDescription();
}
