package hus.oop.lab11.abstractfactory.exercises;

public interface Cat {
    void meow();
}
