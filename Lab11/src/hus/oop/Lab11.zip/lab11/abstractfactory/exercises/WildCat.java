package hus.oop.lab11.abstractfactory.exercises;

public class WildCat implements Cat {
    @Override
    public void meow() {
        System.out.println("Wild cat meow");
    }
}
