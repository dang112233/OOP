package hus.oop.lab11.abstractfactory.exercises;

public class DomesticDog implements Dog {
    @Override
    public void bark() {
        System.out.println("Domestic dog barks");
    }
}
