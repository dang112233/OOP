package hus.oop.lab11.abstractfactory.exercises;

public class WildDog implements Dog {
    @Override
    public void bark() {
        System.out.println("Wild dog: bark");
    }
}
