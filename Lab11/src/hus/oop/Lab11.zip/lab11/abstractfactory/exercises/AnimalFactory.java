package hus.oop.lab11.abstractfactory.exercises;

public interface AnimalFactory {
    Cat createCat();
    Dog createDog();
}
