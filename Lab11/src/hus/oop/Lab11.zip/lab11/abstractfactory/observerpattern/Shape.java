package hus.oop.lab11.abstractfactory.observerpattern;

public interface Shape {
    void draw();
}
