package hus.oop.lab11.abstractfactory.observerpattern;

public abstract class AbstractFactory {
    abstract Shape getShape(String shapeType) ;
}

