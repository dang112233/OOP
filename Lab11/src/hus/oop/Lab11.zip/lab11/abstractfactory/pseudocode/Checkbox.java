package hus.oop.lab11.abstractfactory.pseudocode;

public interface Checkbox {
    void paint();
}
