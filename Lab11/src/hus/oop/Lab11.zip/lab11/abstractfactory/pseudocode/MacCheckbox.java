package hus.oop.lab11.abstractfactory.pseudocode;

public class MacCheckbox implements Checkbox {

    @Override
    public void paint() {
        System.out.println("You have created MacCheckbox.");
    }
}
