package hus.oop.lab11.abstractfactory.pseudocode;

public class WinCheckbox implements Checkbox {
    @Override
    public void paint() {
        System.out.println("You have created WinCheckbox");
    }
}
