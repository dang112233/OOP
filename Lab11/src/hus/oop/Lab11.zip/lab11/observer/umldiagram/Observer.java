package hus.oop.lab11.observer.umldiagram;

public abstract class Observer {
    protected Subject subject;

    public abstract void update();
}
