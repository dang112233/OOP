package hus.oop.lab11.factorymethod.example;

public interface Payment {
    void processPayment(double amount);
}
