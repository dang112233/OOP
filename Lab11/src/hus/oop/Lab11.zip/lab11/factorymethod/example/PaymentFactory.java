package hus.oop.lab11.factorymethod.example;

public interface PaymentFactory {
    Payment createPayment();
}
