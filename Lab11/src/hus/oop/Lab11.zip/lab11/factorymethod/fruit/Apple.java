package hus.oop.lab11.factorymethod.fruit;

public class Apple implements Fruit {
    @Override
    public void produceJuice() {
        System.out.println("Apple juice is produced");
    }

}
