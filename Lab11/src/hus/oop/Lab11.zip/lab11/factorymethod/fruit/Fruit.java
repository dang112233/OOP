package hus.oop.lab11.factorymethod.fruit;

public interface Fruit {
    void produceJuice();
}
