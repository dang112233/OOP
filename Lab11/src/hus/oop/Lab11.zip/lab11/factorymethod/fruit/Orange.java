package hus.oop.lab11.factorymethod.fruit;

public class Orange implements Fruit {
    @Override
    public void produceJuice() {
        System.out.println("Orange juice is produced");
    }
}
