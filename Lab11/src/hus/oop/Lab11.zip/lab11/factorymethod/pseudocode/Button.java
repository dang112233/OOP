package hus.oop.lab11.factorymethod.pseudocode;

public interface Button {
    void render();
    void onClick();
}
