package hus.oop.lab11.iterator.example;

public interface Iterator {
    boolean hasNext();
    Object next();
}
