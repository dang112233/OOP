package hus.oop.lab11.iterator.umldiagram;

public interface Iterator {
    boolean hasNext();

    Object next();
}
