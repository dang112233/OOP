package hus.oop.lab11.iterator.umldiagram;

public interface Iterable {
    Iterator getIterator();
}
