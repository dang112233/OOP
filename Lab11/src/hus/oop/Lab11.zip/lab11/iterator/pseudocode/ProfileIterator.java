package hus.oop.lab11.iterator.pseudocode;

public interface ProfileIterator {
    boolean hasNext();

    Profile getNext();

    void reset();
}
