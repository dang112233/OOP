package hus.oop.lab7.resizablegeometric;

public interface Resizable {
    public void resize(int percent);
}
