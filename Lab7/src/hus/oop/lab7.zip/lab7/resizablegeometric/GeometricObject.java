package hus.oop.lab7.resizablegeometric;

public interface GeometricObject {
    public double getPerimeter();
    public double getArea();
}
