package hus.oop.lab7.viewanimal;

public class Cat extends Animal {
     @Override
    public void greeting() {
         System.out.println("Meow!");
     }
}
