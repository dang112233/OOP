package hus.oop.lab7.viewanimal;

public abstract class Animal {
    abstract public void greeting();
}

