package hus.oop.lab7.geometricobject;

public interface GeometricObject {
    public double getArea();
    public double getPerimeter();
}
