package oop.lab10.adapter.example;

public interface MediaPlayer {
    void play(String audioType, String fileName);
}
