package oop.lab10.strategy.pseudocode;

public interface Strategy {
    int execute(int a, int b);
}
