package oop.lab10.strategy.example;

public interface CompressionStrategy {
    void compress(String fileName);
}
