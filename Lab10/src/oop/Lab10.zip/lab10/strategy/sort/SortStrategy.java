package oop.lab10.strategy.sort;

public interface SortStrategy {
    void sort(int[] arr);
}
